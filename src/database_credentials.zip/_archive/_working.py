import plotly.express as px

# Get the predefined Reds color scale
reds_color_scale = px.colors.sequential.Reds

# Define the length of the color list you want
desired_length = 15

# Interpolate colors to get a list of desired length
selected_colors = [reds_color_scale[int(i * (len(reds_color_scale) - 1) / (desired_length - 1))] for i in range(desired_length)]

print(selected_colors)
