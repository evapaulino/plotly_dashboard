
from itertools import combinations
from math import floor, ceil


ERR_PREFIX = "BesserEsser:"


def make_pie_plot_a(items, *args):
    """
    Makes a simple pie chart with equal slices.
    (plotly-go is used because it was not possibly to deactivate the unnecessary 
    hoverover-tooltips in the figure returned by plotly.express): hoverinfo='skip'
    TODO: test and debug this function to make it work for all cases (df / array)
    """

    # To avoid px error if "unhashable type"
    items = tuple(items)

    fig = go.Figure(data=go.Pie({'labels': items}, hoverinfo='skip'))
    fig.update_traces(textposition='inside', textinfo='label')
    fig.update_layout(hovermode=None, showlegend=False) 
    fig.update_layout(title=get_figure_title(*args))
    return fig


def make_pie_plot_b(items, *args):
    """
    Old version to make a Pie plot - uses plotly express (px) instead of plotly.graphic_objects (go)
    """
    
    # To avoid px error if "unhashable type"
    items = tuple(items) if type(items) is not str else items


    from plotly.colors import n_colors
    n = len(items)
    colors = n_colors('rgb(0, 1, 66)', 
                      'rgb(145, 173, 250)', n+4, colortype = 'rgb')

    #print("DEBUG colors", colors)

    fig = px.pie(names=items,
                 hover_data=[items], 
                 labels={items:'Lebensmittel'},
                 color_discrete_sequence=px.colors.sequential.Oranges,   
                 #hoverinfo='hide',
                #color_discrete_sequence=colors,
                #color=range(1, len(items)+1),
                 )
    fig.update_traces(hoverinfo='label', textfont_size=10,
                  marker=dict(
                      #colors=colors, 
                      line=dict(color='#000000', width=2)))
    fig.update_traces(textposition='inside', textinfo='label')
    fig.update_layout(hovermode=None, showlegend=False)   # how to deactivate tooltips?
    fig.update_layout(title=get_figure_title(args))
    return fig





def compute_median(array):
    """
    custom function to compute the median
    with the implementation specific to the particular task
    at hand
    """
    array = sorted(array)
    
    if len(array) == 0:
        return None
    elif len(array) == 1:
        return array[0]
    
    if len(array) % 2:
        return array[len(array)//2]
    
    median = sum(array[len(array)//2-1:][:2]) / 2

    if median == int(median):
        return int(median)

    mean = sum(array) / len(array)
    return floor(median) if mean < median else ceil(median)  


def get_mean_meal_size(sets: "where 'set' represents an individual meal"):
    """
    rounded mean
    """
    return round(sum(len(st) for st in sets) / len(sets))


def get_median_meal_size(sets: "where 'set' represents an individual meal"):
    return compute_median([len(st) for st in sets])


def get_mode_meal_size(sets):
    # if more than 1 modes -> return mean of those values
    return NotImplemented


def generate_all_possible_subsets(sets, min_cardinality=None, cardinality=None):
    """
    TODO
    """
    
    assert {type(cardinality), type(min_cardinality)}.issubset({type(None), int}), f"cardinality, min_cardinality must be int or None"
    assert (cardinality, min_cardinality).count(None) == 1, f"{ERR_PREFIX}cardinality XOR min_cardinality must be provided"
    
    longest_set_length = max(len(st) for st in sets)
    
    # case cardinality i.e. subsets of length=cardinality
    if cardinality:
        assert 1 <= cardinality <= longest_set_length, f"{ERR_PREFIX}cardinality msut be between 1 and max(len of the sets)"
        
        sets = set(frozenset(st) for st in sets)
        subsets = set()
        
        for st in sets:
            subsets.update(set(frozenset(subset) for subset in combinations(st, r=cardinality)))
        return subsets

    # case min_cardinality i.e. subsets of all sizes
    elif min_cardinality:   # elif is optional here - just to be explicit
        assert 1 <= min_cardinality <= longest_set_length, f"{ERR_PREFIX}min_cardinality msut be between 1 and max(len of the sets)"
    
        subsets = set()
        for n in range(min_cardinality, longest_set_length+1):
            subsets.update(generate_all_possible_subsets(sets, cardinality=n))

        return subsets



def unite_sets_and_all_possible_subsets(sets, min_cardinality=1):
    generate_all_possible_subsets(sets, min_cardinality=min_cardinality)
    return sorted(set(frozenset(st) for st in sets).union(generate_all_possible_subsets(sets, min_cardinality=min_cardinality)),
                 key=lambda st: (len(st), "".join(str(e) for e in st)))



if __name__ == '__main__':
    a,b,c,d,e,f,g,h,i,j,x,y = "abcdefghijxy"
    sets = ls = [{a,b,c,d}, {a,b,c,d}, {a,b,c,f}, {x,y,g}, {x,y,h}, {x,y,i}, {x,y,j}, {x}]
    
    min_cardinality = get_mode_meal_size(sets)
    min_cardinality = get_median_meal_size(sets)
    min_cardinality = get_mean_meal_size(sets)
    
    print("min_cardinality:", min_cardinality)
    
    res = unite_sets_and_all_possible_subsets(sets, min_cardinality=min_cardinality)
    print(*res, sep="\n")




def make_figure_6(df, color=None, debugging_info=None):
    """
    Wie sieht ein typisches Frühstück, Mittagessen oder Abendessen aus
    """

    if len(df) == 0:
        return no_data_available()

    ITEMS_COLUMN_NAME = 'displayname' # comes from the SQL database
    GROUPBY_COLUMN_NAME = 'meal_id'   # comes from the SQL database
    TOP_N = 1             # if TOP_N >1 then must rewrite the code that follows for multiple arrays
    
    """
    sr = (df[[GROUPBY_COLUMN_NAME, ITEMS_COLUMN_NAME]].groupby(GROUPBY_COLUMN_NAME).agg(tuple)
                                            .groupby(ITEMS_COLUMN_NAME).size()
                                            .sort_values(ascending=False).head(TOP_N))
    
    # The following code block will have to be rewritten for multiple lists i.e. if TOP_N > 1
    # items = array with the order (in which the user entered the ingredients) preserved
    items = sr.index.values[0] if len(sr.index.values) > 0 else []

    # HACKISH PATCH - TODO: DEBUG
    TOP_N = 1
    list_of_tuples = (df[['date', 'daytime', 'displayname']].groupby(['date','daytime']).agg(set)
        .reset_index(drop=True).squeeze().apply(sorted).apply(tuple).to_frame()
        .groupby('displayname').size().sort_values(ascending=False).head(TOP_N).index.to_list()  
                    )
    items = list_of_tuples[0] if len(list_of_tuples)>0 else []

    # ANOTHER HACK
    sr = (df[['date', 'daytime', 'displayname']].groupby(['date','daytime']).agg(tuple)
                                            .groupby('displayname').size()
                                            .sort_values(ascending=False).head(TOP_N))
    items = sr.index.values[0] if len(sr.index.values) > 0 else []

    # YET ANOTHER HACK
    TOP_N = 1
    arr = df[['date', 'daytime', 'displayname']].groupby(['date','daytime']).agg(set).values
    list_of_tuples = sorted(Counter(frozenset(e[0]) for e in arr).most_common(TOP_N), key=lambda t: t[1], reverse=True)
    items = [sorted(e[0]) for e in list_of_tuples][0]
    """

    # YET ANOTHER HACK 2
    TOP_N = 1
    arr = df[['date', 'daytime', 'displayname']].groupby(['date','daytime']).agg(list).values.ravel()
    sets = [frozenset(e) for e in arr]
    list_of_lists = [sorted(t[0]) for t in sorted(Counter(sets).most_common(TOP_N), key=lambda t: t[1], reverse=True)]
    items = list_of_lists[0]


    # if no data (just in case)
    if items is None or len(items)==0:
        return no_data_available()
    
    # Tiles or Pie?
    fig = make_pie_plot(items, color)  
    fig.update_layout(title=get_figure_title(debugging_info))
    return fig





def _fetch_clean_eating_data(account_id, engine):
    """
    heleprt function for `get_dataframes`
    not to be used esle weher
    """

    # the input (account_id) should be valid (i.e. int) by now
    # so throw an error here, also to prevent a potential SQL injection
    try:
        account_id = int(account_id)
    except (TypeError, ValueError):
        raise ValueError(f"{ERR_PREFIX}account_id must be (convertable to) int")
    
    # Define an SQL query to merge three tables for the given account
    query = (f"""
SELECT m.account_id, m.date, meal_id, daytime, displayname, ingredient_id
FROM
	{SCHEMA}.meal m LEFT JOIN {SCHEMA}.meal_ingredient mi ON m.id = mi.meal_id 
	LEFT JOIN {SCHEMA}.ingredient i ON mi.ingredient_id = i.id
WHERE account_id = (%s)
ORDER BY m.date, 
		CASE
			WHEN daytime = 'BREAKFAST' THEN 1
			WHEN daytime = 'LUNCH' THEN 2
			WHEN daytime = 'DINNER' THEN 3
            ELSE 9
		END
;""")
    
    # If in debugging mode, print the query 
    if DEBUG:
        print(f"{ERR_PREFIX} SQL query to merge 3 tables into one 'eating' table:\n", query, "\n\n")  # or better: logging.debug()?

    # Get the (already merged) table for account_id
    user_input = (account_id,)
    df = pd.read_sql_query(sql=query, params=user_input, con=engine)

    # Clean
    df.columns = df.columns.str.lower().str.replace(' ', '_')
    df['date'] = pd.to_datetime(df['date'])
    
    # TODO: regex the displayname col (or rather in the click_button function?)
    # in an isolated function
    
    # Drop duplicated rows (based on the subset of cols)
    mask_duplicated = df.duplicated(subset=['account_id', 'date', 'meal_id', 'daytime', 'displayname'], keep='first')
    return df[~mask_duplicated]



def _fetch_clean_symptomreport_data(account_id, engine):
    """TODO"""

    # the input (account_id) should be valid by now (i.e. int or convertable to int)
    # so throw an error here, also to prevent a potential SQL injection
    try:
        account_id = int(account_id)
    except (TypeError, ValueError):
        raise ValueError(f"{ERR_PREFIX}account_id must be (convertable to) int")

    # Query to get the symptomreport table in the right shape (no merging here)
    query = f"""
SELECT
    account_id,
	date, 
	time,
	'-' AS symptom,  --placeholder for the real symptom column
	impairment AS severity
FROM {SCHEMA}.symptomreport
WHERE account_id = (%s)
ORDER BY 
	date, 
	CASE 
		WHEN time = 'AFTER_GETTING_UP' THEN 1
		WHEN time = 'AFTER_BREAKFAST' THEN 2
		WHEN time = 'AFTER_LUNCH' THEN 3
		WHEN time = 'AFTER_DINNER' THEN 4
		WHEN time = 'UNKNOWN' THEN 5
		ELSE 9
	END,
	id --to keep the order in which the user made the entries
;"""
    
    # If in debugging mode, print the query 
    if DEBUG:
        print(f"{ERR_PREFIX} SQL query for 'symtomreport':\n", query, "\n\n") 

    # Fetch the data
    user_input = (account_id,)
    df = pd.read_sql_query(sql=query, params=user_input, con=engine)

    # Clean symptomreport
    df.columns = df.columns.str.lower().str.replace(' ', '_')
    df['date'] = pd.to_datetime(df['date'])
    return df


